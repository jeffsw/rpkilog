#!/usr/bin/env python
import json

def aws_lambda_entry_point(event, context):
    print('PLACEHOLDER lambda invoked by event: ' + json.dumps(event))
    return {
        'statusCode': 200,
        'body': event,
    }

